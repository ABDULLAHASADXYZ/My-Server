<?php

$CONFIG = array (
    "abdullah" => [
        "fullname" => "abdullah", 
        "password" => "root",
    ], 
    
);

?>
